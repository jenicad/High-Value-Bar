﻿namespace HighBarAppWF
{
    public class Clinic
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}